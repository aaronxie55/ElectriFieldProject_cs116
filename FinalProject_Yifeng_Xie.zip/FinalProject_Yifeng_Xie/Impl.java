
public interface Impl {
	public abstract double calculateCosine(Particle p,Charge c);
	public abstract double calculateSine(Particle p,Charge c);
	public abstract String calculateDirection(Particle p,Charge c);
}
